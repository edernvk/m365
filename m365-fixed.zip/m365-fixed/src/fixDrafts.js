#!/usr/bin/env node
/**
 * fixDrafts.js — Corrige mensagens migradas incorretamente como [Rascunho]
 *
 * Para cada usuário no users.csv:
 *   1. Lista todos os e-mails no destino com isDraft:true
 *   2. Busca o original correspondente na origem (por subject + receivedDateTime)
 *   3. Deleta o rascunho do destino
 *   4. Recria corretamente com PATCH isDraft:false
 *
 * Usage:
 *   node src/fixDrafts.js                        # todos os usuários
 *   node src/fixDrafts.js --user email@domain    # só um usuário
 *   node src/fixDrafts.js --dry-run              # simulação sem alterar nada
 */

const fs   = require('fs');
const path = require('path');
const minimist = require('minimist');
const chalk = require('chalk');
const TenantAuth  = require('./auth');
const GraphClient = require('./graphClient');
const UserLoader  = require('./userLoader');
const Logger      = require('./logger');

const MIGRATION_PROPERTY_ID = 'String {8ECCC264-6880-4EBE-992F-8888D2EEAA1D} Name SourceMessageId';

const argv   = minimist(process.argv.slice(2));
const ONLY_USER = argv.user || argv.u || null;
const DRY_RUN   = argv['dry-run'] || argv.d || false;
const PAGE_SIZE = 100;

// ── Load config ───────────────────────────────────────────────────────────────
let config;
try {
  config = JSON.parse(fs.readFileSync(path.resolve(process.cwd(), 'config.json'), 'utf8'));
} catch (e) {
  console.error(chalk.red('❌ config.json not found'));
  process.exit(1);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const u = ['B','KB','MB','GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${u[i]}`;
}

// ── Get all mail folders (top + children) ─────────────────────────────────────
async function getAllFolders(client, userEmail) {
  const folders = [];
  for await (const f of client.paginate(`/users/${userEmail}/mailFolders`)) {
    folders.push(f);
    for await (const c of client.paginate(`/users/${userEmail}/mailFolders/${f.id}/childFolders`)) {
      folders.push(c);
    }
  }
  return folders;
}

// ── Get all drafts in a folder ────────────────────────────────────────────────
async function getDraftsInFolder(client, userEmail, folderId) {
  const drafts = [];
  let skip = 0;
  while (true) {
    const result = await client.get(
      `/users/${userEmail}/mailFolders/${folderId}/messages`,
      {
        '$top': PAGE_SIZE,
        '$skip': skip,
        '$filter': 'isDraft eq true',
        '$select': 'id,subject,receivedDateTime,sentDateTime,isDraft,body,from,toRecipients,ccRecipients,bccRecipients,replyTo,flag,importance,isRead',
        '$expand': `singleValueExtendedProperties($filter=id eq '${MIGRATION_PROPERTY_ID}')`
      }
    );
    const msgs = result.value || [];
    drafts.push(...msgs);
    if (msgs.length < PAGE_SIZE) break;
    skip += PAGE_SIZE;
  }
  return drafts;
}

// ── Find original message in source by subject + date ─────────────────────────
async function findOriginalInSource(srcClient, userEmail, folderId, subject, receivedDateTime) {
  try {
    // Escape single quotes in subject for OData filter
    const safeSubject = (subject || '').replace(/'/g, "''");
    const result = await srcClient.get(
      `/users/${userEmail}/mailFolders/${folderId}/messages`,
      {
        '$top': 1,
        '$filter': `subject eq '${safeSubject}' and receivedDateTime eq ${receivedDateTime}`,
        '$select': 'id,subject,receivedDateTime,sentDateTime,isDraft,body,from,toRecipients,ccRecipients,bccRecipients,replyTo,flag,importance,isRead,internetMessageHeaders'
      }
    );
    return (result.value || [])[0] || null;
  } catch (e) {
    return null;
  }
}

// ── Fix a single folder ────────────────────────────────────────────────────────
async function fixFolder(srcClient, tgtClient, srcEmail, tgtEmail, srcFolderId, tgtFolderId, folderName, logger, stats) {
  const drafts = await getDraftsInFolder(tgtClient, tgtEmail, tgtFolderId);

  if (drafts.length === 0) return;

  logger.info(`   📁 ${folderName}: ${chalk.yellow(drafts.length + ' drafts found')} — fixing...`);

  for (const draft of drafts) {
    // Check if this was migrated by our tool (has SourceMessageId property)
    const sourceProp = draft.singleValueExtendedProperties?.find(p => p.id === MIGRATION_PROPERTY_ID);
    const sourceId   = sourceProp?.value || null;

    if (DRY_RUN) {
      logger.info(`   [DRY RUN] Would fix: "${draft.subject}" (${draft.receivedDateTime})`);
      stats.fixed++;
      continue;
    }

    // Try to get full original from source
    let original = null;

    if (sourceId) {
      // Best case: we have the source message ID, fetch it directly
      try {
        original = await srcClient.get(
          `/users/${srcEmail}/messages/${sourceId}`,
          { '$select': 'id,subject,receivedDateTime,sentDateTime,isDraft,body,from,toRecipients,ccRecipients,bccRecipients,replyTo,flag,importance,isRead,internetMessageHeaders' }
        );
      } catch (e) { /* fall through to subject search */ }
    }

    if (!original && draft.subject && draft.receivedDateTime) {
      // Fallback: search by subject + date in the source folder
      original = await findOriginalInSource(srcClient, srcEmail, srcFolderId, draft.subject, draft.receivedDateTime);
    }

    if (!original) {
      // Source not found — use the draft's own body to recreate it correctly
      logger.warn(`   ⚠️  Source not found for "${draft.subject}" — recreating from draft copy`);
      try {
        // Sanitize headers from draft itself
        const draftHeaders = [];
        const seenH = new Set();
        for (const h of (draft.internetMessageHeaders || [])) {
          const name = h?.name?.toLowerCase();
          if (name && name.startsWith('x-') && !seenH.has(name)) {
            seenH.add(name);
            draftHeaders.push(h);
          }
        }

        const fallbackDate = draft.receivedDateTime || draft.sentDateTime;

        // Build payload from the draft itself
        const fallbackPayload = {
          subject:       draft.subject || '(sem assunto)',
          body:          draft.body || { contentType: 'text', content: '' },
          from:          draft.from,
          toRecipients:  draft.toRecipients  || [],
          ccRecipients:  draft.ccRecipients  || [],
          bccRecipients: draft.bccRecipients || [],
          replyTo:       draft.replyTo       || [],
          receivedDateTime: draft.receivedDateTime,
          sentDateTime:     draft.sentDateTime,
          isRead:    draft.isRead,
          flag:      draft.flag,
          importance: draft.importance || 'normal',
          internetMessageHeaders: draftHeaders.slice(0, 5),
          singleValueExtendedProperties: [
            fallbackDate && { id: 'SystemTime 0x0E06', value: fallbackDate },
            draft.sentDateTime && { id: 'SystemTime 0x0039', value: draft.sentDateTime },
          ].filter(Boolean)
        };

        // Delete old draft
        await tgtClient.request('DELETE', `/users/${tgtEmail}/messages/${draft.id}`);

        // Recreate from draft data
        const recreated = await tgtClient.post(
          `/users/${tgtEmail}/mailFolders/${tgtFolderId}/messages`,
          fallbackPayload
        );

        // PATCH to finalize
        await tgtClient.patch(
          `/users/${tgtEmail}/messages/${recreated.id}`,
          { isDraft: false }
        );

        logger.info(`   ✓ Recreated from draft: "${draft.subject}"`);
        stats.fixed++;
      } catch (e) {
        logger.error(`   ✗ Failed to fix "${draft.subject}": ${e.message}`);
        stats.failed++;
      }
      continue;
    }

    try {
      // 1. Delete the bad draft
      await tgtClient.request('DELETE', `/users/${tgtEmail}/messages/${draft.id}`);

      // 2. Sanitize headers
      const customHeaders = [];
      const seen = new Set();
      for (const h of (original.internetMessageHeaders || [])) {
        const name = h?.name?.toLowerCase();
        if (name && name.startsWith('x-') && !seen.has(name)) {
          seen.add(name);
          customHeaders.push(h);
        }
      }

      const originalDate = original.receivedDateTime || original.sentDateTime;

      // 3. Recreate with correct payload
      const payload = {
        subject:       original.subject || '(sem assunto)',
        body:          original.body || { contentType: 'text', content: '' },
        from:          original.from,
        toRecipients:  original.toRecipients  || [],
        ccRecipients:  original.ccRecipients  || [],
        bccRecipients: original.bccRecipients || [],
        replyTo:       original.replyTo       || [],
        receivedDateTime: original.receivedDateTime,
        sentDateTime:     original.sentDateTime,
        isRead:    original.isRead,
        flag:      original.flag,
        importance: original.importance || 'normal',
        internetMessageHeaders: customHeaders.slice(0, 5),
        singleValueExtendedProperties: [
          { id: 'SystemTime 0x0E06', value: originalDate },
          { id: 'SystemTime 0x0039', value: original.sentDateTime || originalDate },
          { id: MIGRATION_PROPERTY_ID, value: original.id }
        ].filter(p => p.value)
      };

      const created = await tgtClient.post(
        `/users/${tgtEmail}/mailFolders/${tgtFolderId}/messages`,
        payload
      );

      // 4. PATCH to remove draft status
      await tgtClient.patch(
        `/users/${tgtEmail}/messages/${created.id}`,
        { isDraft: false }
      );

      logger.info(`   ✓ Fixed: "${original.subject}"`);
      stats.fixed++;

    } catch (err) {
      logger.error(`   ✗ Failed to fix "${draft.subject}": ${err.message}`);
      stats.failed++;
    }

    await sleep(300); // gentle throttle
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────
async function main() {
  const mainLogger = new Logger(config.logs_dir || './logs', 'fixdrafts');

  console.log(chalk.bold.cyan('\n🔧 M365 Draft Fixer'));
  console.log(chalk.gray(`   Source: ${config.source_tenant.domain}`));
  console.log(chalk.gray(`   Target: ${config.target_tenant.domain}`));
  if (DRY_RUN) console.log(chalk.yellow('   ⚠️  DRY RUN — nothing will be changed\n'));
  else console.log('');

  // Load users
  const userLoader = new UserLoader(config.users_csv || './users.csv');
  let users = userLoader.load();
  if (ONLY_USER) {
    users = users.filter(u => u.sourceEmail.toLowerCase() === ONLY_USER.toLowerCase());
    if (!users.length) { mainLogger.error(`User not found in CSV: ${ONLY_USER}`); process.exit(1); }
  }

  // Auth
  mainLogger.info('Authenticating...');
  const srcAuth = new TenantAuth(config.source_tenant, 'SOURCE');
  const tgtAuth = new TenantAuth(config.target_tenant, 'TARGET');
  await srcAuth.getToken();
  await tgtAuth.getToken();
  const srcClient = new GraphClient(srcAuth, config.migration, mainLogger);
  const tgtClient = new GraphClient(tgtAuth, config.migration, mainLogger);
  mainLogger.success('Both tenants authenticated ✓\n');

  const globalStats = { fixed: 0, failed: 0, users: 0 };

  for (const user of users) {
    const logger = new Logger(config.logs_dir || './logs', user.sourceEmail);
    logger.info(`\n👤 Processing: ${user.sourceEmail} → ${user.targetEmail}`);

    const stats = { fixed: 0, failed: 0 };

    try {
      // Get folders from both tenants
      const [srcFolders, tgtFolders] = await Promise.all([
        getAllFolders(srcClient, user.sourceEmail),
        getAllFolders(tgtClient, user.targetEmail)
      ]);

      // Build name → id map for target folders
      const tgtFolderMap = {};
      for (const f of tgtFolders) tgtFolderMap[f.displayName] = f.id;

      // Well-known folder name map (PT-BR → well-known ID)
      const wellKnown = {
        'Caixa de Entrada': 'inbox', 'Inbox': 'inbox',
        'Itens Enviados': 'sentitems', 'Sent Items': 'sentitems',
        'Itens Excluídos': 'deleteditems', 'Deleted Items': 'deleteditems',
        'Rascunhos': 'drafts', 'Drafts': 'drafts',
        'Lixo Eletrônico': 'junkemail', 'Junk Email': 'junkemail',
        'Arquivo Morto': 'archive', 'Archive': 'archive',
      };

      let totalDraftsFolder = 0;

      for (const srcFolder of srcFolders) {
        // Find matching target folder
        let tgtFolderId = tgtFolderMap[srcFolder.displayName];

        if (!tgtFolderId && wellKnown[srcFolder.displayName]) {
          try {
            const f = await tgtClient.get(`/users/${user.targetEmail}/mailFolders/${wellKnown[srcFolder.displayName]}`);
            tgtFolderId = f.id;
          } catch (e) { /* skip */ }
        }

        if (!tgtFolderId) continue;

        // Count drafts before fixing
        const draftsBefore = await getDraftsInFolder(tgtClient, user.targetEmail, tgtFolderId);
        if (draftsBefore.length === 0) continue;

        totalDraftsFolder += draftsBefore.length;

        await fixFolder(
          srcClient, tgtClient,
          user.sourceEmail, user.targetEmail,
          srcFolder.id, tgtFolderId,
          srcFolder.displayName,
          logger, stats
        );
      }

      if (totalDraftsFolder === 0) {
        logger.info('   ✅ No draft messages found — nothing to fix!');
      } else {
        logger.success(`   Done: ${stats.fixed} fixed, ${stats.failed} failed`);
      }

      globalStats.fixed  += stats.fixed;
      globalStats.failed += stats.failed;
      globalStats.users++;

    } catch (err) {
      logger.error(`Failed processing ${user.sourceEmail}: ${err.message}`);
    }
  }

  console.log('\n' + chalk.bold('─'.repeat(50)));
  console.log(chalk.bold.green(`✅ Fix complete!`));
  console.log(chalk.green(`   Users processed: ${globalStats.users}`));
  console.log(chalk.green(`   Messages fixed:  ${globalStats.fixed}`));
  if (globalStats.failed > 0)
    console.log(chalk.red(`   Failures:        ${globalStats.failed}`));
  console.log('');
}

main().catch(err => {
  console.error(chalk.red('Fatal:'), err.message);
  process.exit(1);
});
